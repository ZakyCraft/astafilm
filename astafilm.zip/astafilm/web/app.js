// Konfigurasi Endpoint Backend AstaFilm
const API_BASE = '/api';
const EMBED_BASE_URL = 'https://vidsrc.me/embed';

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const viewCatalog = document.getElementById('viewCatalog');
  const viewWatch = document.getElementById('viewWatch');
  
  const grid = document.getElementById('grid');
  const featuredGrid = document.getElementById('featuredGrid');
  const relatedGrid = document.getElementById('relatedGrid');
  const searchForm = document.getElementById('search');
  const searchInput = document.getElementById('q');
  const refreshBtn = document.getElementById('refresh');
  const sectionTitle = document.getElementById('sectionTitle');
  const backBtn = document.getElementById('backBtn');
  const logoBtn = document.getElementById('logoBtn');
  const genreContainer = document.getElementById('genreContainer');
  const loadingSpinner = document.getElementById('loadingSpinner');

  const playerIframe = document.getElementById('playerIframe');
  const watchTitle = document.getElementById('watchTitle');
  const watchMeta = document.getElementById('watchMeta');
  const watchOverview = document.getElementById('watchOverview');
  const tvControls = document.getElementById('tvControls');
  const updateTvBtn = document.getElementById('updateTvBtn');
  const adShield = document.getElementById('adShield');

  // State Variables
  let currentMovies = [];
  let currentPage = 1;
  let isLoading = false;
  let hasMorePages = true;
  let currentActiveGenre = 'all';
  let currentSearchQuery = '';
  let renderedMovieIds = new Set();
  let observer = null;

  // Inisialisasi Data & Observer
  loadMovies(true);
  setupInfiniteScroll();

  // ----------------------------------------------------
  // 1. Safe Infinite Scroll (IntersectionObserver)
  // ----------------------------------------------------
  function setupInfiniteScroll() {
    if (!loadingSpinner) return;

    if (observer) observer.disconnect();

    observer = new IntersectionObserver((entries) => {
      const entry = entries[0];
      
      // Request HANYA dipanggil jika indikator loading benar-benar terlihat di layar
      if (entry.isIntersecting && !isLoading && hasMorePages) {
        if (viewCatalog && !viewCatalog.classList.contains('hidden')) {
          currentPage++;
          if (currentSearchQuery) {
            searchMedia(currentSearchQuery, false);
          } else if (currentActiveGenre === 'all') {
            loadMovies(false);
          } else {
            // Jika dalam mode genre spesifik, fetch halaman selanjutnya dari TMDB/Backend
            fetchByGenrePage(currentActiveGenre, false);
          }
        }
      }
    }, {
      root: null,
      rootMargin: '200px', // Pre-fetch 200px sebelum bagian paling bawah tersentuh
      threshold: 0.1
    });

    observer.observe(loadingSpinner);
  }

  // ----------------------------------------------------
  // 2. Filter Kategori Genre
  // ----------------------------------------------------
  if (genreContainer) {
    genreContainer.addEventListener('click', (e) => {
      if (e.target.classList.contains('sub-nav-btn')) {
        document.querySelectorAll('.sub-nav-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');

        const genreId = e.target.getAttribute('data-genre');
        const genreName = e.target.textContent;

        currentActiveGenre = genreId;
        currentSearchQuery = '';
        currentPage = 1;

        if (genreId === 'all') {
          loadMovies(true);
        } else {
          filterByGenre(genreId, genreName);
        }
      }
    });
  }

  function filterByGenre(genreId, genreName) {
    if (sectionTitle) sectionTitle.textContent = `Kategori: ${genreName}`;

    // Filter film yang sudah ada di memori
    const filtered = currentMovies.filter(item => 
      item.genre_ids && item.genre_ids.includes(parseInt(genreId))
    );

    if (filtered.length > 0) {
      renderGridItems(filtered, true);
    } else {
      // Jika film dengan genre tsb belum ter-load, fetch data dari backend
      fetchByGenrePage(genreId, true);
    }
  }

  async function fetchByGenrePage(genreId, isReset = false) {
    if (isLoading) return;
    isLoading = true;
    if (loadingSpinner) loadingSpinner.style.display = 'block';

    if (isReset) {
      currentPage = 1;
      renderedMovieIds.clear();
      if (grid) grid.innerHTML = '';
    }

    try {
      // Mengambil data trending dan memfilter genre ID
      const res = await fetch(`${API_BASE}/trending?page=${currentPage}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();
      const results = data.results || [];

      const filtered = results.filter(item => 
        item.genre_ids && item.genre_ids.includes(parseInt(genreId))
      );

      if (results.length === 0) hasMorePages = false;

      renderGridItems(filtered, isReset);
    } catch (err) {
      console.error('Error fetching genre:', err);
    } finally {
      isLoading = false;
      if (loadingSpinner) loadingSpinner.style.display = 'none';
    }
  }

  // ----------------------------------------------------
  // 3. Event Navigation & Event Listeners
  // ----------------------------------------------------
  if (logoBtn) logoBtn.addEventListener('click', showCatalog);
  if (backBtn) backBtn.addEventListener('click', showCatalog);

  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      if (searchInput) searchInput.value = '';
      currentSearchQuery = '';
      currentActiveGenre = 'all';
      currentPage = 1;
      document.querySelectorAll('.sub-nav-btn').forEach(btn => btn.classList.remove('active'));
      const defaultBtn = document.querySelector('.sub-nav-btn[data-genre="all"]');
      if (defaultBtn) defaultBtn.classList.add('active');
      loadMovies(true);
    });
  }

  if (searchForm) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const query = searchInput ? searchInput.value.trim() : '';
      if (query) {
        showCatalog();
        currentSearchQuery = query;
        currentPage = 1;
        searchMedia(query, true);
      }
    });
  }

  if (adShield) {
    adShield.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      adShield.style.display = 'none';
    });
  }

  // ----------------------------------------------------
  // 4. Fetching Data (API Backend)
  // ----------------------------------------------------
  async function loadMovies(isReset = false) {
    if (isLoading) return;
    isLoading = true;
    if (loadingSpinner) loadingSpinner.style.display = 'block';

    if (isReset) {
      currentPage = 1;
      currentMovies = [];
      renderedMovieIds.clear();
      hasMorePages = true;
      if (grid) grid.innerHTML = '';
      if (sectionTitle) sectionTitle.textContent = 'Film Terbaru';
    }

    try {
      const res = await fetch(`${API_BASE}/trending?page=${currentPage}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();
      const newItems = data.results || [];

      if (newItems.length === 0) {
        hasMorePages = false;
      } else {
        currentMovies = [...currentMovies, ...newItems];

        if (isReset) {
          renderFeaturedRow(newItems.slice(0, 10));
        }

        renderGridItems(newItems, isReset);
      }
    } catch (err) {
      console.error('Error fetching movies:', err);
      hasMorePages = false;
    } finally {
      isLoading = false;
      if (loadingSpinner) loadingSpinner.style.display = 'none';
    }
  }

  async function searchMedia(query, isReset = false) {
    if (isLoading) return;
    isLoading = true;
    if (loadingSpinner) loadingSpinner.style.display = 'block';

    if (isReset) {
      currentPage = 1;
      renderedMovieIds.clear();
      hasMorePages = true;
      if (grid) grid.innerHTML = '';
      if (sectionTitle) sectionTitle.textContent = `Hasil Pencarian: "${query}"`;
    }

    try {
      const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(query)}&page=${currentPage}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();
      const results = data.results || [];

      if (results.length === 0) {
        hasMorePages = false;
      }

      renderGridItems(results, isReset);
    } catch (err) {
      console.error('Error searching:', err);
      hasMorePages = false;
    } finally {
      isLoading = false;
      if (loadingSpinner) loadingSpinner.style.display = 'none';
    }
  }

  // ----------------------------------------------------
  // 5. Rendering Layout DOM
  // ----------------------------------------------------
  function renderFeaturedRow(items) {
    if (!featuredGrid) return;
    featuredGrid.innerHTML = '';
    items.forEach(item => {
      const card = createCardElement(item);
      card.style.minWidth = '140px';
      featuredGrid.appendChild(card);
    });
  }

  function renderGridItems(items, isReset = false) {
    if (!grid) return;

    if (isReset) {
      grid.innerHTML = '';
    }

    if (!items.length && grid.children.length === 0) {
      grid.innerHTML = '<p class="muted" style="grid-column: 1/-1; text-align: center; padding: 40px 0;">Tidak ada film ditemukan.</p>';
      return;
    }

    const fragment = document.createDocumentFragment();

    items.forEach(item => {
      if (!item.id || renderedMovieIds.has(item.id)) return;
      renderedMovieIds.add(item.id);

      const card = createCardElement(item);
      fragment.appendChild(card);
    });

    grid.appendChild(fragment);
  }

  function createCardElement(item) {
    const card = document.createElement('div');
    card.className = 'card';
    const poster = item.poster_path 
      ? `https://image.tmdb.org/t/p/w500${item.poster_path}` 
      : 'https://via.placeholder.com/500x750?text=No+Poster';
    
    const title = item.title || item.name || 'Untitled';
    const year = (item.release_date || item.first_air_date || '').substring(0, 4);
    const rating = item.vote_average ? item.vote_average.toFixed(1) : 'N/A';
    const quality = item.first_air_date ? 'EPS' : 'HD';

    card.innerHTML = `
      <div class="card-poster">
        <span class="badge-rating">⭐ ${rating}</span>
        <span class="badge-quality">${quality}</span>
        <img src="${poster}" alt="${title}" loading="lazy">
      </div>
      <div class="card-body">
        <h4>${title}</h4>
        <p>${year}</p>
      </div>
    `;

    card.addEventListener('click', () => {
      openWatchPage(item);
    });

    return card;
  }

  // ----------------------------------------------------
  // 6. Player Page (Watch Mode)
  // ----------------------------------------------------
  function openWatchPage(item) {
    const tmdbId = item.id;
    const mediaType = item.media_type || (item.first_air_date ? 'tv' : 'movie');
    const title = item.title || item.name || 'Untitled';
    const year = (item.release_date || item.first_air_date || '').substring(0, 4);
    const rating = item.vote_average ? item.vote_average.toFixed(1) : 'N/A';
    const isTv = mediaType === 'tv';

    if (watchTitle) watchTitle.textContent = title;
    if (watchMeta) watchMeta.textContent = `${mediaType.toUpperCase()} • ${year} • ⭐ ${rating}`;
    if (watchOverview) watchOverview.textContent = item.overview || 'Tidak ada deskripsi sinopsis.';

    if (adShield) adShield.style.display = 'block';

    if (isTv) {
      if (tvControls) tvControls.classList.remove('hidden');
      const s = document.getElementById('seasonInput') ? document.getElementById('seasonInput').value || 1 : 1;
      const e = document.getElementById('episodeInput') ? document.getElementById('episodeInput').value || 1 : 1;
      
      if (playerIframe) {
        playerIframe.src = `${EMBED_BASE_URL}/tv?tmdb=${tmdbId}&season=${s}&episode=${e}`;
      }

      if (updateTvBtn) {
        updateTvBtn.onclick = () => {
          const season = document.getElementById('seasonInput').value || 1;
          const episode = document.getElementById('episodeInput').value || 1;
          playerIframe.src = `${EMBED_BASE_URL}/tv?tmdb=${tmdbId}&season=${season}&episode=${episode}`;
        };
      }
    } else {
      if (tvControls) tvControls.classList.add('hidden');
      if (playerIframe) {
        playerIframe.src = `${EMBED_BASE_URL}/movie?tmdb=${tmdbId}`;
      }
    }

    renderRelatedList(currentMovies.filter(i => i.id !== tmdbId));

    if (viewCatalog) viewCatalog.classList.add('hidden');
    if (viewWatch) viewWatch.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function renderRelatedList(items) {
    if (!relatedGrid) return;
    relatedGrid.innerHTML = '';
    items.slice(0, 8).forEach(item => {
      const relCard = document.createElement('div');
      relCard.className = 'related-item';
      const poster = item.poster_path 
        ? `https://image.tmdb.org/t/p/w185${item.poster_path}` 
        : 'https://via.placeholder.com/185x278?text=No+Poster';
      
      const title = item.title || item.name || 'Untitled';
      const year = (item.release_date || item.first_air_date || '').substring(0, 4);

      relCard.innerHTML = `
        <img src="${poster}" alt="${title}">
        <div class="related-info">
          <h4>${title}</h4>
          <p>${year} • ⭐ ${item.vote_average ? item.vote_average.toFixed(1) : 'N/A'}</p>
        </div>
      `;

      relCard.addEventListener('click', () => {
        openWatchPage(item);
      });

      relatedGrid.appendChild(relCard);
    });
  }

  function showCatalog() {
    if (playerIframe) playerIframe.src = '';
    if (viewWatch) viewWatch.classList.add('hidden');
    if (viewCatalog) viewCatalog.classList.remove('hidden');
  }
});