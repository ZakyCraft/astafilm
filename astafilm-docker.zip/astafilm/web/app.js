const grid = document.querySelector("#grid");
const sources = document.querySelector("#sources");
const modal = document.querySelector("#modal");
const detail = document.querySelector("#detail");

const img = p => p ? `https://image.tmdb.org/t/p/w500${p}` : "";
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
}[c]));

function card(item, onClick) {
  const title = item.title || item.name || "Tanpa judul";
  const year = (item.release_date || item.first_air_date || "").slice(0,4);
  const el = document.createElement("article");
  el.className = "card";
  el.innerHTML = `
    <img class="poster" src="${img(item.poster_path)}" onerror="this.style.visibility='hidden'">
    <div class="card-body">
      <div class="title">${esc(title)}</div>
      <div class="meta">${esc(year || "—")} · ${item.vote_average ? Number(item.vote_average).toFixed(1) : "—"}</div>
    </div>`;
  el.onclick = () => onClick(item);
  return el;
}

async function loadTrending() {
  grid.innerHTML = '<div class="empty">Memuat...</div>';
  const r = await fetch("/api/trending");
  const d = await r.json();
  grid.innerHTML = "";
  (d.results || []).filter(x => x.media_type !== "person").forEach(x => grid.appendChild(card(x, showMovie)));
}

async function search(q) {
  grid.innerHTML = '<div class="empty">Mencari...</div>';
  document.querySelector("#sectionTitle").textContent = `Hasil: ${q}`;
  const r = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
  const d = await r.json();
  grid.innerHTML = "";
  (d.results || []).filter(x => x.media_type !== "person").forEach(x => grid.appendChild(card(x, showMovie)));
}

async function showMovie(item) {
  if (!item.id || item.media_type === "tv") {
    detail.innerHTML = `<h2>${esc(item.title || item.name)}</h2><p class="muted">Detail TV bisa ditambahkan pada endpoint berikutnya.</p>`;
    modal.classList.remove("hidden");
    return;
  }
  const r = await fetch(`/api/movie/${item.id}`);
  const m = await r.json();
  const genres = (m.genres || []).map(g => g.name).join(", ");
  detail.innerHTML = `
    <div class="detail">
      <img src="${img(m.poster_path)}" onerror="this.style.visibility='hidden'">
      <div>
        <p class="eyebrow">MOVIE</p>
        <h2>${esc(m.title)}</h2>
        <p class="meta">${esc((m.release_date||"").slice(0,4))} · ${esc(genres)} · ${m.vote_average ? Number(m.vote_average).toFixed(1) : "—"}</p>
        <p class="muted">${esc(m.overview || "Tidak ada sinopsis.")}</p>
        <p class="meta">Cast: ${esc((m.credits?.cast || []).slice(0,5).map(x=>x.name).join(", "))}</p>
      </div>
    </div>`;
  modal.classList.remove("hidden");
}

async function loadSources() {
  const r = await fetch("/api/sources");
  const d = await r.json();
  sources.innerHTML = "";
  if (!d.length) {
    sources.innerHTML = '<div class="empty">Belum ada video yang ditambahkan.</div>';
    return;
  }
  d.forEach(x => {
    const el = document.createElement("article");
    el.className = "card";
    el.innerHTML = `
      <img class="poster" src="${esc(x.poster_url || "")}" onerror="this.style.visibility='hidden'">
      <div class="card-body">
        <div class="title">${esc(x.title)}</div>
        <div class="meta">${esc(x.year || "—")}</div>
      </div>`;
    el.onclick = () => {
      detail.innerHTML = `
        <h2>${esc(x.title)}</h2>
        <video class="player" controls playsinline preload="metadata" src="${esc(x.video_url)}"></video>`;
      modal.classList.remove("hidden");
    };
    sources.appendChild(el);
  });
}

document.querySelector("#search").onsubmit = e => {
  e.preventDefault();
  const q = document.querySelector("#q").value.trim();
  if (q) search(q);
};
document.querySelector("#refresh").onclick = () => {
  document.querySelector("#sectionTitle").textContent = "Trending hari ini";
  loadTrending();
};
document.querySelector("#close").onclick = () => modal.classList.add("hidden");
modal.onclick = e => { if (e.target === modal) modal.classList.add("hidden"); };

loadTrending();
loadSources();
