# Astafilm — Docker starter

Website katalog film legal dengan metadata TMDB dan player untuk URL video yang kamu punya hak distribusinya.

## Stack
- Nginx reverse proxy
- Static frontend
- Fastify API
- SQLite
- TMDB metadata API
- HTML5 video player

## Jalankan
1. Copy `.env.example` menjadi `.env`
2. Isi `TMDB_API_KEY`
3. Jalankan:
   `docker compose up -d --build`
4. Buka:
   `http://IP-VPS:8080`

## Tambah sumber video
Masuk ke API:
`POST /api/admin/sources`

Contoh JSON:
```json
{
  "title": "Contoh Film",
  "video_url": "https://domain-kamu.example/movie.mp4",
  "poster_url": "https://...",
  "year": 2026
}
```

Catatan: hanya masukkan video yang kamu miliki atau berhak distribusikan.
Untuk production, tambahkan authentication pada endpoint admin dan HTTPS.
