import Fastify from "fastify";
import cors from "@fastify/cors";
import Database from "better-sqlite3";

const app = Fastify({ logger: true });
await app.register(cors, { origin: true });

const db = new Database("/app/data/astafilm.db");
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    video_url TEXT NOT NULL,
    poster_url TEXT,
    year INTEGER,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

const TMDB_BASE = "https://api.themoviedb.org/3";
const TMDB_KEY = process.env.TMDB_API_KEY || "";

async function tmdb(path, params = {}) {
  if (!TMDB_KEY) {
    throw new Error("TMDB_API_KEY belum diisi");
  }
  const url = new URL(TMDB_BASE + path);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${TMDB_KEY}`,
      accept: "application/json"
    }
  });
  if (!res.ok) throw new Error(`TMDB HTTP ${res.status}`);
  return res.json();
}

app.get("/api/health", async () => ({
  ok: true,
  service: "astafilm-api"
}));

app.get("/api/search", async (req, reply) => {
  try {
    const q = String(req.query.q || "").trim();
    if (!q) return { results: [] };
    return await tmdb("/search/multi", {
      query: q,
      include_adult: "false",
      language: "id-ID"
    });
  } catch (e) {
    reply.code(500);
    return { error: e.message };
  }
});

app.get("/api/trending", async (req, reply) => {
  try {
    return await tmdb("/trending/all/day", { language: "id-ID" });
  } catch (e) {
    reply.code(500);
    return { error: e.message };
  }
});

app.get("/api/movie/:id", async (req, reply) => {
  try {
    return await tmdb(`/movie/${req.params.id}`, {
      language: "id-ID",
      append_to_response: "credits"
    });
  } catch (e) {
    reply.code(500);
    return { error: e.message };
  }
});

app.get("/api/sources", async () => {
  return db.prepare(`
    SELECT id, title, video_url, poster_url, year, created_at
    FROM sources ORDER BY id DESC
  `).all();
});

app.post("/api/admin/sources", async (req, reply) => {
  const { title, video_url, poster_url = "", year = null } = req.body || {};
  if (!title || !video_url) {
    reply.code(400);
    return { error: "title dan video_url wajib" };
  }
  const result = db.prepare(`
    INSERT INTO sources (title, video_url, poster_url, year)
    VALUES (?, ?, ?, ?)
  `).run(title, video_url, poster_url, year || null);
  return { ok: true, id: result.lastInsertRowid };
});

app.delete("/api/admin/sources/:id", async (req, reply) => {
  db.prepare("DELETE FROM sources WHERE id = ?").run(req.params.id);
  return { ok: true };
});

app.listen({
  host: "0.0.0.0",
  port: Number(process.env.PORT || 3000)
});
